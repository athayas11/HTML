from django.apps import AppConfig


class DateappConfig(AppConfig):
    name = 'dateapp'
